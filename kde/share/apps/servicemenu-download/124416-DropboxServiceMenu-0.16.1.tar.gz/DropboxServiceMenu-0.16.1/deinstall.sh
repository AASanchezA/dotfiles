#!/bin/bash
cd "`kde4-config --localprefix`/share/kde4/services/ServiceMenus/"
rm dropbox_all.desktop dropbox_files.desktop dropbox_directories.desktop
rm -r dropbox-scripts


